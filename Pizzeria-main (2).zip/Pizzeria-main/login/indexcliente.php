
<?php

session_start();
error_reporting (0);
if($_SESSION['tipo'] == 2) {

include("../recursos/vistas/header.php");
require("../db/conexion.php");

?>
<h1>cliente</h1>
<?php
} else {
    echo '<script language="javascript">alert("Para ingresar a éste sitio se requiere iniciar sesión como usuario cliente.");</script>';
            echo "<script>location.href='indexadmin.php'</script>";
}
?>
