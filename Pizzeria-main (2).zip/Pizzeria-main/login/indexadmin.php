
<?php

session_start();
error_reporting (0);
if($_SESSION['tipo'] == 1) {

include("../recursos/vistas/headera.php");
require("../db/conexion.php");

?>
<h1>Admin</h1>
<?php
} else {
    echo '<script language="javascript">alert("Para ingresar a éste sitio se requiere iniciar sesión como usuario admin.");</script>';
            echo "<script>location.href='indexcliente.php'</script>";
}
?>
